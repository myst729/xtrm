# Xtrm

Firmware for [Xtrm](https://github.com/myst729/xtrm). An extremely borderless mechanical keyboard PCB, 40% staggered layout with an encoder.

# Xtrm

Firmware for [Xtrm](https://github.com/myst729/xtrm). An extremely borderless mechanical keyboard, 40% staggered layout with an encoder.
